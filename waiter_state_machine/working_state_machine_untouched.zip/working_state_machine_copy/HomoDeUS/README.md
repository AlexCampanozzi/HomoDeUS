# HomoDeUS
Welcome to the repo for HomoDeUS, a project by a group of students at the Université de Sherbrooke to program a Tiago robot with the goal of participating in the 2021 RoboCup@Home Competition. 
